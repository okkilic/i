<?php
session_start();
include('ez_sql_core.php');
include('ez_sql_mysqli.php');

$db = new ezSQL_mysqli('root','','ziyaretci_formu','localhost');
$db->query("SET NAMES 'utf8'");
$db->query("SET CHARACTER SET utf8");
$db->query("SET COLLATION_CONNECTION = 'utf8_general_ci'");


// Buradaki işlem yorum kısmına koyulan sil ve düzenle butonlarını herkesin görmemesi için. bu şifre ile giriş yapan tüm adminler silme değiştirme işlemi yapabilsin. bu bilgiyi de session da saklıyoruz güvenlik için

define('sifre', 'sifre123');



?>